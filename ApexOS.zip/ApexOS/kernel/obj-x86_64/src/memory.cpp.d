obj-x86_64/src/memory.cpp.o: src/memory.cpp \
  freestanding-cxx-hdrs/include/cstddef \
  freestanding-cxx-hdrs/include/__fcxx/config.h \
  freestanding-cxx-hdrs/include/__fcxx/std_decls.h \
  freestanding-cxx-hdrs/include/__fcxx/version.h \
  freestanding-cxx-hdrs/include/__fcxx/version_bit.h \
  freestanding-cxx-hdrs/include/__fcxx/version_atomic.h \
  freestanding-cxx-hdrs/include/__fcxx/version_ratio.h \
  freestanding-cxx-hdrs/include/__fcxx/version_charconv.h \
  freestanding-cxx-hdrs/include/__fcxx/version_random.h \
  freestanding-cxx-hdrs/include/__fcxx/version_containers.h \
  freestanding-cxx-hdrs/include/__fcxx/version_strings.h \
  freestanding-cxx-hdrs/include/__fcxx/version_optional.h \
  freestanding-cxx-hdrs/include/__fcxx/version_ranges.h \
  freestanding-cxx-hdrs/include/__fcxx/version_algorithm.h \
  freestanding-cxx-hdrs/include/__fcxx/version_utility.h \
  freestanding-cxx-hdrs/include/__fcxx/version_memory.h \
  freestanding-cxx-hdrs/include/__fcxx/version_functional.h \
  freestanding-cxx-hdrs/include/__fcxx/version_iterator.h \
  freestanding-c-hdrs/include/stddef.h \
  freestanding-c-hdrs/include/__freestanding_c_hdrs/revision.h \
  freestanding-cxx-hdrs/include/__fcxx/c_revision.h \
  freestanding-cxx-hdrs/include/__fcxx/c_stddef.h \
  freestanding-cxx-hdrs/include/cstdint \
  freestanding-c-hdrs/include/stdint.h \
  freestanding-cxx-hdrs/include/__fcxx/c_stdint.h src/memory.hpp
freestanding-cxx-hdrs/include/cstddef:
freestanding-cxx-hdrs/include/__fcxx/config.h:
freestanding-cxx-hdrs/include/__fcxx/std_decls.h:
freestanding-cxx-hdrs/include/__fcxx/version.h:
freestanding-cxx-hdrs/include/__fcxx/version_bit.h:
freestanding-cxx-hdrs/include/__fcxx/version_atomic.h:
freestanding-cxx-hdrs/include/__fcxx/version_ratio.h:
freestanding-cxx-hdrs/include/__fcxx/version_charconv.h:
freestanding-cxx-hdrs/include/__fcxx/version_random.h:
freestanding-cxx-hdrs/include/__fcxx/version_containers.h:
freestanding-cxx-hdrs/include/__fcxx/version_strings.h:
freestanding-cxx-hdrs/include/__fcxx/version_optional.h:
freestanding-cxx-hdrs/include/__fcxx/version_ranges.h:
freestanding-cxx-hdrs/include/__fcxx/version_algorithm.h:
freestanding-cxx-hdrs/include/__fcxx/version_utility.h:
freestanding-cxx-hdrs/include/__fcxx/version_memory.h:
freestanding-cxx-hdrs/include/__fcxx/version_functional.h:
freestanding-cxx-hdrs/include/__fcxx/version_iterator.h:
freestanding-c-hdrs/include/stddef.h:
freestanding-c-hdrs/include/__freestanding_c_hdrs/revision.h:
freestanding-cxx-hdrs/include/__fcxx/c_revision.h:
freestanding-cxx-hdrs/include/__fcxx/c_stddef.h:
freestanding-cxx-hdrs/include/cstdint:
freestanding-c-hdrs/include/stdint.h:
freestanding-cxx-hdrs/include/__fcxx/c_stdint.h:
src/memory.hpp:
