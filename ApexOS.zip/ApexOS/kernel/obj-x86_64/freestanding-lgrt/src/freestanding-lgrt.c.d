obj-x86_64/freestanding-lgrt/src/freestanding-lgrt.c.o: \
  freestanding-lgrt/src/freestanding-lgrt.c \
  freestanding-c-hdrs/include/float.h \
  freestanding-c-hdrs/include/__freestanding_c_hdrs/revision.h \
  freestanding-c-hdrs/include/limits.h \
  freestanding-c-hdrs/include/stdbool.h \
  freestanding-c-hdrs/include/stddef.h \
  freestanding-c-hdrs/include/stdint.h \
  freestanding-c-hdrs/include/stdatomic.h
freestanding-c-hdrs/include/float.h:
freestanding-c-hdrs/include/__freestanding_c_hdrs/revision.h:
freestanding-c-hdrs/include/limits.h:
freestanding-c-hdrs/include/stdbool.h:
freestanding-c-hdrs/include/stddef.h:
freestanding-c-hdrs/include/stdint.h:
freestanding-c-hdrs/include/stdatomic.h:
