#include <cstddef>
#include <cstdint>
#include <limine.h>

#define APEXOS_BETA 1

#define BLACK  0x000000
#define WHITE  0xFFFFFF
#define GREEN  0x00FF00
#define GREY   0x888888
#define RED    0xFF4444
#define BLUE   0x4488FF
#define YELLOW 0xFFFF00

#define SCALE 2
#define CHAR_W 12
#define LINE_H 18
#define MAX_INPUT 128

__attribute__((used, section(".limine_requests_start")))
static volatile uint64_t limine_requests_start_marker[] = LIMINE_REQUESTS_START_MARKER;

__attribute__((used, section(".limine_requests")))
static volatile uint64_t limine_base_revision[] = LIMINE_BASE_REVISION(6);

__attribute__((used, section(".limine_requests")))
static volatile struct limine_framebuffer_request framebuffer_request = {
    .id = LIMINE_FRAMEBUFFER_REQUEST_ID,
    .revision = 0
};

__attribute__((used, section(".limine_requests_end")))
static volatile uint64_t limine_requests_end_marker[] = LIMINE_REQUESTS_END_MARKER;

static limine_framebuffer* fb = nullptr;
static std::size_t cursor_x = 16;
static std::size_t cursor_y = 16;

static char username[16] = "USER";
static char input[MAX_INPUT];
static std::size_t input_length = 0;
static bool waiting_for_name = false;

static bool shift_down = false;
static bool caps_lock = false;

static const std::uint8_t font[36][5] = {
    {0x7E,0x11,0x11,0x11,0x7E}, // A
    {0x7F,0x49,0x49,0x49,0x36}, // B
    {0x3E,0x41,0x41,0x41,0x22}, // C
    {0x7F,0x41,0x41,0x22,0x1C}, // D
    {0x7F,0x49,0x49,0x49,0x41}, // E
    {0x7F,0x09,0x09,0x09,0x01}, // F
    {0x3E,0x41,0x49,0x49,0x7A}, // G
    {0x7F,0x08,0x08,0x08,0x7F}, // H
    {0x00,0x41,0x7F,0x41,0x00}, // I
    {0x20,0x40,0x41,0x3F,0x01}, // J
    {0x7F,0x08,0x14,0x22,0x41}, // K
    {0x7F,0x40,0x40,0x40,0x40}, // L
    {0x7F,0x02,0x0C,0x02,0x7F}, // M
    {0x7F,0x04,0x08,0x10,0x7F}, // N
    {0x3E,0x41,0x41,0x41,0x3E}, // O
    {0x7F,0x09,0x09,0x09,0x06}, // P
    {0x3E,0x41,0x51,0x21,0x5E}, // Q
    {0x7F,0x09,0x19,0x29,0x46}, // R
    {0x46,0x49,0x49,0x49,0x31}, // S
    {0x01,0x01,0x7F,0x01,0x01}, // T
    {0x3F,0x40,0x40,0x40,0x3F}, // U
    {0x1F,0x20,0x40,0x20,0x1F}, // V
    {0x7F,0x20,0x18,0x20,0x7F}, // W
    {0x63,0x14,0x08,0x14,0x63}, // X
    {0x03,0x04,0x78,0x04,0x03}, // Y
    {0x61,0x51,0x49,0x45,0x43}, // Z

    {0x3E,0x51,0x49,0x45,0x3E}, // 0
    {0x00,0x42,0x7F,0x40,0x00}, // 1
    {0x42,0x61,0x51,0x49,0x46}, // 2
    {0x21,0x41,0x45,0x4B,0x31}, // 3
    {0x18,0x14,0x12,0x7F,0x10}, // 4
    {0x27,0x45,0x45,0x45,0x39}, // 5
    {0x3C,0x4A,0x49,0x49,0x30}, // 6
    {0x01,0x71,0x09,0x05,0x03}, // 7
    {0x36,0x49,0x49,0x49,0x36}, // 8
    {0x06,0x49,0x49,0x29,0x1E}  // 9
};

static void hcf() {
    for (;;) {
        asm volatile("cli; hlt");
    }
}

static std::uint32_t pack_color(std::uint32_t color) {
    std::uint32_t r = (color >> 16) & 255;
    std::uint32_t g = (color >> 8) & 255;
    std::uint32_t b = color & 255;

    auto channel = [](std::uint32_t value,
                      std::uint8_t size,
                      std::uint8_t shift) -> std::uint32_t {
        if (size == 0) return 0;
        std::uint64_t max = (1ULL << size) - 1;
        return static_cast<std::uint32_t>(
            ((value * max + 127) / 255) << shift
        );
    };

    return channel(r, fb->red_mask_size, fb->red_mask_shift) |
           channel(g, fb->green_mask_size, fb->green_mask_shift) |
           channel(b, fb->blue_mask_size, fb->blue_mask_shift);
}

static void pixel(std::size_t x, std::size_t y,
                  std::uint32_t color) {
    if (!fb || x >= fb->width || y >= fb->height) return;

    volatile std::uint32_t* address =
        reinterpret_cast<volatile std::uint32_t*>(
            reinterpret_cast<std::uintptr_t>(fb->address) +
            y * fb->pitch + x * 4
        );

    *address = pack_color(color);
}

static void rectangle(std::size_t x, std::size_t y,
                      std::size_t w, std::size_t h,
                      std::uint32_t color) {
    for (std::size_t yy = y; yy < y + h; yy++) {
        for (std::size_t xx = x; xx < x + w; xx++) {
            pixel(xx, yy, color);
        }
    }
}

static int font_index(char c) {
    if (c >= 'a' && c <= 'z') c -= 32;
    if (c >= 'A' && c <= 'Z') return c - 'A';
    if (c >= '0' && c <= '9') return 26 + c - '0';
    return -1;
}

static std::uint8_t punctuation(char c, int col) {
    static const std::uint8_t question[5] = {0x02,0x01,0x51,0x09,0x06};
    static const std::uint8_t colon[5]    = {0x00,0x36,0x36,0x00,0x00};
    static const std::uint8_t period[5]   = {0x00,0x60,0x60,0x00,0x00};
    static const std::uint8_t comma[5]    = {0x00,0x40,0x20,0x00,0x00};
    static const std::uint8_t dash[5]     = {0x08,0x08,0x08,0x08,0x08};
    static const std::uint8_t underscore[5] = {0x40,0x40,0x40,0x40,0x40};
    static const std::uint8_t slash[5]    = {0x20,0x10,0x08,0x04,0x02};
    static const std::uint8_t equal[5]    = {0x14,0x14,0x14,0x14,0x14};
    static const std::uint8_t less[5]     = {0x08,0x14,0x22,0x41,0x00};
    static const std::uint8_t greater[5]  = {0x00,0x41,0x22,0x14,0x08};
    static const std::uint8_t exclaim[5] = {0x00,0x00,0x5F,0x00,0x00};

    const std::uint8_t* p = question;

    switch (c) {
        case ':': p = colon; break;
        case '.': p = period; break;
        case ',': p = comma; break;
        case '-': p = dash; break;
        case '_': p = underscore; break;
        case '/': p = slash; break;
        case '=': p = equal; break;
        case '<': p = less; break;
        case '>': p = greater; break;
        case '!': p = exclaim; break;
        default: break;
    }

    return p[col];
}

static void draw_character(std::size_t x, std::size_t y,
                           char c, std::uint32_t color) {
    if (c == ' ') {
        rectangle(x, y, CHAR_W, LINE_H, BLACK);
        return;
    }

    int index = font_index(c);

    for (int col = 0; col < 6; col++) {
        for (int row = 0; row < 8; row++) {
            bool on = false;

            if (col < 5 && row < 7) {
                std::uint8_t bits = index >= 0
                    ? font[index][col]
                    : punctuation(c, col);

                on = (bits >> row) & 1;
            }

            rectangle(x + col * SCALE, y + row * SCALE,
                      SCALE, SCALE, on ? color : BLACK);
        }
    }
}

static void scroll_screen() {
    const std::size_t rows = fb->height - LINE_H;

    for (std::size_t y = 0; y < rows; y++) {
        for (std::size_t x = 0; x < fb->width; x++) {
            volatile std::uint32_t* dst =
                reinterpret_cast<volatile std::uint32_t*>(
                    reinterpret_cast<std::uintptr_t>(fb->address) +
                    y * fb->pitch + x * 4
                );

            volatile std::uint32_t* src =
                reinterpret_cast<volatile std::uint32_t*>(
                    reinterpret_cast<std::uintptr_t>(fb->address) +
                    (y + LINE_H) * fb->pitch + x * 4
                );

            *dst = *src;
        }
    }

    rectangle(0, rows, fb->width, LINE_H, BLACK);
    cursor_y = rows;
}

static void newline() {
    cursor_x = 16;
    cursor_y += LINE_H;

    if (cursor_y + LINE_H >= fb->height) {
        scroll_screen();
    }
}

static void put_char(char c, std::uint32_t color = WHITE) {
    if (c == '\n') {
        newline();
        return;
    }

    if (c == '\b') {
        if (cursor_x > 16) {
            cursor_x -= CHAR_W;
            rectangle(cursor_x, cursor_y, CHAR_W, LINE_H, BLACK);
        }
        return;
    }

    if (cursor_x + CHAR_W >= fb->width) {
        newline();
    }

    draw_character(cursor_x, cursor_y, c, color);
    cursor_x += CHAR_W;
}

static void print(const char* s, std::uint32_t color = WHITE) {
    while (*s) put_char(*s++, color);
}

static void println(const char* s, std::uint32_t color = WHITE) {
    print(s, color);
    newline();
}

static bool equal(const char* a, const char* b) {
    while (*a && *b) {
        char x = *a++;
        char y = *b++;

        if (x >= 'a' && x <= 'z') x -= 32;
        if (y >= 'a' && y <= 'z') y -= 32;

        if (x != y) return false;
    }

    return *a == *b;
}

static void copy_name(const char* s) {
    std::size_t i = 0;

    while (s[i] && i < sizeof(username) - 1) {
        username[i] = s[i];
        i++;
    }

    username[i] = 0;
}

static void prompt() {
    print("<", GREEN);
    print(username, GREEN);
    print(": ", GREEN);
}

static void banner() {
    println("APEXOS  Vb1.0  THIS IS NOT A RELEASE  BETA  1.0  TEST 1", GREEN);
    println("TYPE HELP FOR AVAILABLE CMDS", WHITE);
    println("TYPE NAME TO RENAME YOUR USER", WHITE);
}

static void clear_screen() {
    rectangle(0, 0, fb->width, fb->height, BLACK);
    cursor_x = 16;
    cursor_y = 16;
}

static void show_help() {
    println("APEXOS COMMAND LIST", GREEN);
    println("-------------------", GREY);
    println("HELP       - SHOW COMMANDS");
    println("CLEAR      - CLEAR SCREEN");
    println("CLS        - CLEAR SCREEN");
    println("ABOUT      - ABOUT APEXOS");
    println("VERSION    - SHOW VERSION");
    println("VER        - SHOW VERSION");
    println("NAME       - RENAME YOUR USER");
    println("WHOAMI     - SHOW YOUR USERNAME");
    println("ECHO       - PRINT TEXT");
    println("BANNER     - SHOW APEXOS BANNER");
    println("LS         - LIST VIRTUAL FILES");
    println("PWD        - SHOW CURRENT LOCATION");
    println("UNAME      - SYSTEM INFORMATION");
    println("MOTD       - MESSAGE OF THE DAY");
    println("CREDITS    - APEXOS CREDITS");
    println("REBOOT     - RESTART THE VM");
    println("SHUTDOWN   - STOP THE VM");
#if APEXOS_BETA
    println("DEV        - BETA DEVELOPER COMMANDS", YELLOW);
#endif
}

static void dev_command(const char* args) {
#if APEXOS_BETA
    if (equal(args, "INFO")) {
        println("APEXOS DEVELOPER INFORMATION", YELLOW);
        println("VERSION: VB1.0");
        println("CHANNEL: BETA");
        println("BOOTLOADER: LIMINE");
        println("DISPLAY: FRAMEBUFFER");
        println("INPUT: PS/2 KEYBOARD");
        println("SHELL: APEXOS BUILT-IN");
    } else if (equal(args, "HELP") || *args == 0) {
        println("BETA DEVELOPER COMMANDS", YELLOW);
        println("DEV HELP  - THIS LIST");
        println("DEV INFO  - SYSTEM DETAILS");
        println("DEV TEST  - SCREEN TEST");
        println("DEV COLOR - COLOR TEST");
    } else if (equal(args, "TEST")) {
        println("APEXOS BETA TEST", YELLOW);
        println("KEYBOARD: ENABLED", GREEN);
        println("TEXT OUTPUT: ENABLED", GREEN);
        println("FRAMEBUFFER: ENABLED", GREEN);
        println("SHELL: ENABLED", GREEN);
    } else if (equal(args, "COLOR")) {
        println("GREEN TEXT", GREEN);
        println("WHITE TEXT", WHITE);
        println("YELLOW TEXT", YELLOW);
        println("BLUE TEXT", BLUE);
        println("RED TEXT", RED);
    } else {
        println("UNKNOWN DEV COMMAND. TYPE DEV HELP.", RED);
    }
#else
    (void)args;
    println("DEV COMMANDS ARE NOT AVAILABLE IN THIS BUILD.", RED);
#endif
}

static void reboot_system() {
    println("REBOOTING...", YELLOW);

    for (volatile int i = 0; i < 1000000; i++) {
        asm volatile("pause");
    }

    asm volatile("cli");
    std::uint8_t good = 0x02;

    while (good & 0x02) {
        asm volatile("inb $0x64, %0" : "=a"(good));
    }

    asm volatile("outb %0, $1" : : "a"((unsigned char)0xFE));

    hcf();
}

static void run_command(char* line) {
    while (*line == ' ') line++;

    if (*line == 0) return;

    char* args = line;

    while (*args && *args != ' ') args++;

    if (*args) {
        *args++ = 0;
        while (*args == ' ') args++;
    }

    if (equal(line, "HELP")) {
        show_help();
    } else if (equal(line, "CLEAR") || equal(line, "CLS")) {
        clear_screen();
    } else if (equal(line, "ABOUT")) {
        println("APEXOS IS A TEXT-BASED OPERATING SYSTEM.");
        println("BUILT AS A LEARNING PROJECT.");
        println("CURRENTLY RUNNING A BETA VERSION.");
    } else if (equal(line, "VERSION") || equal(line, "VER")) {
        println("APEXOS VB1.0 - BETA TEST 1", GREEN);
    } else if (equal(line, "WHOAMI")) {
        println(username, GREEN);
    } else if (equal(line, "NAME")) {
        if (*args) {
            copy_name(args);
            print("USERNAME CHANGED TO ", GREEN);
            println(username, GREEN);
        } else {
            waiting_for_name = true;
            println("ENTER YOUR NEW USERNAME:", YELLOW);
        }
    } else if (equal(line, "ECHO")) {
        println(args);
    } else if (equal(line, "BANNER")) {
        banner();
    } else if (equal(line, "LS")) {
        println("README.TXT");
        println("COMMANDS.TXT");
        println("THESE ARE VIRTUAL FILES.");
    } else if (equal(line, "PWD")) {
        println("/");
    } else if (equal(line, "UNAME")) {
        println("APEXOS X86_64");
    } else if (equal(line, "MOTD")) {
        println("WELCOME TO APEXOS BETA!");
        println("THANK YOU FOR TESTING.");
    } else if (equal(line, "CREDITS")) {
        println("APEXOS PROJECT");
        println("BOOTLOADER: LIMINE");
        println("THANKS FOR TESTING APEXOS!");
    } else if (equal(line, "DEV")) {
        dev_command(args);
    } else if (equal(line, "REBOOT")) {
        reboot_system();
    } else if (equal(line, "SHUTDOWN")) {
        println("SHUTTING DOWN. YOU CAN CLOSE THE VM.", YELLOW);
        hcf();
    } else {
        print("UNKNOWN COMMAND: ", RED);
        println(line, RED);
        println("TYPE HELP TO SEE AVAILABLE COMMANDS.");
    }
}

static std::uint8_t inb(std::uint16_t port) {
    std::uint8_t value;
    asm volatile("inb %1, %0" : "=a"(value) : "Nd"(port));
    return value;
}

static char keyboard_character(std::uint8_t code) {
    if (code >= 0x80) {
        if (code == 0xAA || code == 0xB6) shift_down = false;
        return 0;
    }

    if (code == 0x2A || code == 0x36) {
        shift_down = true;
        return 0;
    }

    if (code == 0x3A) {
        caps_lock = !caps_lock;
        return 0;
    }

    if (code == 0x0E) return '\b';
    if (code == 0x1C) return '\n';
    if (code == 0x39) return ' ';

    const char* normal = nullptr;
    const char* shifted = nullptr;
    int index = -1;

    if (code >= 0x02 && code <= 0x0D) {
        normal = "1234567890-=";
        shifted = "!@#$%^&*()_+";
        index = code - 0x02;
    } else if (code >= 0x10 && code <= 0x1B) {
        normal = "qwertyuiop[]";
        shifted = "QWERTYUIOP{}";
        index = code - 0x10;
    } else if (code >= 0x1E && code <= 0x28) {
        normal = "asdfghjkl;'";
        shifted = "ASDFGHJKL:\"";
        index = code - 0x1E;
    } else if (code >= 0x2C && code <= 0x35) {
        normal = "zxcvbnm,./";
        shifted = "ZXCVBNM<>?";
        index = code - 0x2C;
    }

    if (normal && index >= 0) {
        char c = normal[index];

        if (c >= 'a' && c <= 'z') {
            if (shift_down != caps_lock) c -= 32;
        } else if (shift_down) {
            c = shifted[index];
        }

        return c;
    }

    return 0;
}

static void shell() {
    banner();
    newline();

    for (;;) {
        prompt();
        input_length = 0;

        for (;;) {
            while (!(inb(0x64) & 1)) {
                asm volatile("pause");
            }

            std::uint8_t code = inb(0x60);
            char c = keyboard_character(code);

            if (!c) continue;

            if (c == '\b') {
                if (input_length > 0) {
                    input_length--;
                    put_char('\b');
                }
                continue;
            }

            if (c == '\n') {
                newline();
                input[input_length] = 0;

                if (waiting_for_name) {
                    waiting_for_name = false;

                    if (input_length > 0) {
                        copy_name(input);
                        print("USERNAME CHANGED TO ", GREEN);
                        println(username, GREEN);
                    } else {
                        println("USERNAME NOT CHANGED.", RED);
                    }
                } else {
                    run_command(input);
                }

                break;
            }

            if (input_length < MAX_INPUT - 1) {
                input[input_length++] = c;
                put_char(c);
            }
        }
    }
}

extern "C" void __cxa_pure_virtual() { hcf(); }
extern "C" void __cxa_deleted_virtual() { hcf(); }
extern "C" void _init() {}
extern "C" void _fini() {}

extern "C" void kmain(void) {
    if (!LIMINE_BASE_REVISION_SUPPORTED(limine_base_revision)) hcf();

    if (framebuffer_request.response == nullptr) hcf();
    if (framebuffer_request.response->framebuffer_count < 1) hcf();

    fb = framebuffer_request.response->framebuffers[0];

    if (fb == nullptr || fb->address == nullptr || fb->bpp != 32) hcf();

    clear_screen();
    println("MADE BY PARGE-DEV ON GITHUB", 0x00FF00);
    println(" ", WHITE);
    shell();
}
