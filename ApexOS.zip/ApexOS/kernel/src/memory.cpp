#include <cstddef>
#include <cstdint>
#include <memory.hpp>

// GCC and Clang reserve the right to generate calls to the following 4
// C-linkage functions even if they are not directly called. They must be
// implemented as the C specification mandates. DO NOT remove or rename these
// functions, or stuff will eventually break.

extern "C" {

#ifdef memcpy
#   undef memcpy
#endif
void *memcpy(void *__restrict dest, const void *__restrict src, std::size_t n) {
    std::uint8_t *pdest = static_cast<std::uint8_t *>(dest);
    const std::uint8_t *psrc = static_cast<const std::uint8_t *>(src);

    for (std::size_t i = 0; i < n; i++) {
        pdest[i] = psrc[i];
    }

    return dest;
}

#ifdef memset
#   undef memset
#endif
void *memset(void *s, int c, std::size_t n) {
    std::uint8_t *p = static_cast<std::uint8_t *>(s);

    for (std::size_t i = 0; i < n; i++) {
        p[i] = static_cast<std::uint8_t>(c);
    }

    return s;
}

#ifdef memmove
#   undef memmove
#endif
void *memmove(void *dest, const void *src, std::size_t n) {
    std::uint8_t *pdest = static_cast<std::uint8_t *>(dest);
    const std::uint8_t *psrc = static_cast<const std::uint8_t *>(src);

    if (reinterpret_cast<std::uintptr_t>(src) > reinterpret_cast<std::uintptr_t>(dest)) {
        for (std::size_t i = 0; i < n; i++) {
            pdest[i] = psrc[i];
        }
    } else if (reinterpret_cast<std::uintptr_t>(src) < reinterpret_cast<std::uintptr_t>(dest)) {
        for (std::size_t i = n; i-- > 0; ) {
            pdest[i] = psrc[i];
        }
    }

    return dest;
}

#ifdef memcmp
#   undef memcmp
#endif
int memcmp(const void *s1, const void *s2, std::size_t n) {
    const std::uint8_t *p1 = static_cast<const std::uint8_t *>(s1);
    const std::uint8_t *p2 = static_cast<const std::uint8_t *>(s2);

    for (std::size_t i = 0; i < n; i++) {
        if (p1[i] != p2[i]) {
            return p1[i] < p2[i] ? -1 : 1;
        }
    }

    return 0;
}

}
