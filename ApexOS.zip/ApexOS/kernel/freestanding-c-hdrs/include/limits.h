/* SPDX-License-Identifier: 0BSD
 *
 * Copyright (C) 2022-2026 Mintsuki and contributors.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
 * SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION
 * OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
 * CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

#ifndef __FREESTANDING_C_HDRS_LIMITS_H
#define __FREESTANDING_C_HDRS_LIMITS_H 1

#pragma GCC system_header

#include <__freestanding_c_hdrs/revision.h>

#undef CHAR_BIT
#define CHAR_BIT __CHAR_BIT__

/* MB_LEN_MAX is left out. It is the most bytes that a multibyte character has
   in any of the locales, and only a hosted environment has locales. */

#undef SCHAR_MAX
#define SCHAR_MAX __SCHAR_MAX__
#undef SCHAR_MIN
#define SCHAR_MIN (-SCHAR_MAX - 1)

#undef UCHAR_MAX
#if __SCHAR_MAX__ == __INT_MAX__
#   define UCHAR_MAX (SCHAR_MAX * 2U + 1U)
#else
#   define UCHAR_MAX (SCHAR_MAX * 2 + 1)
#endif

#ifdef __CHAR_UNSIGNED__
#   undef CHAR_MAX
#   define CHAR_MAX UCHAR_MAX
#   undef CHAR_MIN
#   if __SCHAR_MAX__ == __INT_MAX__
#       define CHAR_MIN 0U
#   else
#       define CHAR_MIN 0
#   endif
#else
#   undef CHAR_MAX
#   define CHAR_MAX SCHAR_MAX
#   undef CHAR_MIN
#   define CHAR_MIN SCHAR_MIN
#endif

#undef SHRT_MAX
#define SHRT_MAX __SHRT_MAX__
#undef SHRT_MIN
#define SHRT_MIN (-SHRT_MAX - 1)

#undef USHRT_MAX
#if __SHRT_MAX__ == __INT_MAX__
#   define USHRT_MAX (SHRT_MAX * 2U + 1U)
#else
#   define USHRT_MAX (SHRT_MAX * 2 + 1)
#endif

#undef INT_MAX
#define INT_MAX __INT_MAX__
#undef INT_MIN
#define INT_MIN (-INT_MAX - 1)

#undef UINT_MAX
#define UINT_MAX (INT_MAX * 2U + 1U)

#undef LONG_MAX
#define LONG_MAX __LONG_MAX__
#undef LONG_MIN
#define LONG_MIN (-LONG_MAX - 1L)

#undef ULONG_MAX
#define ULONG_MAX (LONG_MAX * 2UL + 1UL)

#if __FREESTANDING_C_HDRS_LIMITS_REVISION >= 199901L
#   undef LLONG_MAX
#   define LLONG_MAX __LONG_LONG_MAX__
#   undef LLONG_MIN
#   define LLONG_MIN (-LLONG_MAX - 1LL)

#   undef ULLONG_MAX
#   define ULLONG_MAX (LLONG_MAX * 2ULL + 1ULL)
#endif

#if __FREESTANDING_C_HDRS_LIMITS_REVISION >= 202311L
    /* C23 has the widths of the character types expand to the same value as
       CHAR_BIT. */
#   undef CHAR_WIDTH
#   define CHAR_WIDTH CHAR_BIT
#   undef SCHAR_WIDTH
#   define SCHAR_WIDTH CHAR_BIT
#   undef UCHAR_WIDTH
#   define UCHAR_WIDTH CHAR_BIT
#   undef SHRT_WIDTH
#   define SHRT_WIDTH __SHRT_WIDTH__
#   undef USHRT_WIDTH
#   define USHRT_WIDTH __SHRT_WIDTH__
#   undef INT_WIDTH
#   define INT_WIDTH __INT_WIDTH__
#   undef UINT_WIDTH
#   define UINT_WIDTH __INT_WIDTH__
#   undef LONG_WIDTH
#   define LONG_WIDTH __LONG_WIDTH__
#   undef ULONG_WIDTH
#   define ULONG_WIDTH __LONG_WIDTH__
    /* GCC names the width of long long __LONG_LONG_WIDTH__, as it does its
       __LONG_LONG_MAX__, and Clang names it __LLONG_WIDTH__. */
#   if defined(__clang__)
#       undef LLONG_WIDTH
#       define LLONG_WIDTH __LLONG_WIDTH__
#       undef ULLONG_WIDTH
#       define ULLONG_WIDTH __LLONG_WIDTH__
#   else
#       undef LLONG_WIDTH
#       define LLONG_WIDTH __LONG_LONG_WIDTH__
#       undef ULLONG_WIDTH
#       define ULLONG_WIDTH __LONG_LONG_WIDTH__
#   endif

#   undef BOOL_MAX
#   define BOOL_MAX 1
#   undef BOOL_WIDTH
#   define BOOL_WIDTH 1

    /* C++26 does not take this one from C23. */
#   if !defined(__cplusplus) && defined(__BITINT_MAXWIDTH__)
#       undef BITINT_MAXWIDTH
#       define BITINT_MAXWIDTH __BITINT_MAXWIDTH__
#   endif

#   undef __STDC_VERSION_LIMITS_H__
#   define __STDC_VERSION_LIMITS_H__ 202311L
#endif

#endif
